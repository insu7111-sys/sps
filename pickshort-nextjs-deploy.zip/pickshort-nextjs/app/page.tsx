"use client";

import { useMemo, useState } from "react";
import products from "../data/products.json";

type Product = {
  id: string;
  category: string;
  title: string;
  description: string;
  name: string;
  priceLabel: string;
  emoji: string;
  background: string;
  videoUrl: string;
  imageUrl?: string;
  affiliateUrl: string;
  tags: string[];
};

const categories = ["전체", "주방", "생활", "디지털", "정리"];

export default function Home() {
  const [category, setCategory] = useState("전체");
  const [search, setSearch] = useState("");
  const items = products as Product[];

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase();
    return items.filter((p) => {
      const categoryMatch = category === "전체" || p.category === category;
      const text = [p.title, p.description, p.name, p.category, ...p.tags].join(" ").toLocaleLowerCase();
      return categoryMatch && (!q || text.includes(q));
    });
  }, [category, search, items]);

  return (
    <main>
      <header className="topbar">
        <a className="logo" href="/" aria-label="픽숏 홈">픽<span>숏</span></a>
        <label className="searchbox">
          <span className="srOnly">상품 검색</span>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="상품 또는 키워드 검색"
          />
          <span className="searchIcon" aria-hidden="true">⌕</span>
        </label>
      </header>

      <div className="container">
        <section className="hero">
          <div>
            <div className="eyebrow">PICK · WATCH · SHOP</div>
            <h1>짧게 보고,<br className="mobileBreak" /> 똑똑하게 쇼핑</h1>
            <p>생활을 편하게 만드는 아이디어 상품을 숏츠처럼 만나보세요.</p>
          </div>
          <aside className="disclosure">
            <strong>쿠팡 파트너스 제휴 안내</strong>
            <p>이 페이지는 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받을 수 있습니다.</p>
          </aside>
        </section>

        <nav className="categories" aria-label="상품 카테고리">
          {categories.map((c) => (
            <button key={c} className={category === c ? "category active" : "category"} onClick={() => setCategory(c)}>
              {c === "전체" ? "전체" : c === "주방" ? "주방 아이템" : c === "생활" ? "생활 꿀템" : c === "디지털" ? "디지털" : "정리·수납"}
            </button>
          ))}
        </nav>

        <div className="layout">
          <section className="feed" aria-label="추천 상품 숏츠">
            {filtered.length ? filtered.map((p) => (
              <article className="shortCard" key={p.id}>
                <div className="videoFrame" style={{ background: p.background }}>
                  {p.videoUrl ? (
                    <video
                      className="video"
                      src={p.videoUrl}
                      poster={p.imageUrl || undefined}
                      controls
                      playsInline
                      preload="metadata"
                      aria-label={`${p.name} 소개 영상`}
                    />
                  ) : p.imageUrl ? (
                    // 이미지 URL을 등록하면 영상 대신 상품 소개 이미지가 표시됩니다.
                    // eslint-disable-next-line @next/next/no-img-element
                    <img className="posterImage" src={p.imageUrl} alt={p.name} />
                  ) : (
                    <div className="placeholder">
                      <span className="productEmoji" aria-hidden="true">{p.emoji}</span>
                      <span className="placeholderLabel">영상 URL을 등록하세요</span>
                    </div>
                  )}
                  <span className="tag">{p.category} 추천</span>
                  <div className="videoCaption">
                    <h2>{p.title}</h2>
                    <p>{p.description}</p>
                  </div>
                </div>
                <div className="productInfo">
                  <div className="productName">{p.name}</div>
                  <div className="productMeta">
                    <span className="price">{p.priceLabel || "가격 확인"}</span>
                    {p.affiliateUrl && p.affiliateUrl !== "PASTE_YOUR_COUPANG_PARTNERS_LINK_HERE" ? (
                      <a className="buyButton" href={p.affiliateUrl} target="_blank" rel="sponsored nofollow noopener noreferrer">
                        쿠팡에서 보기 ↗
                      </a>
                    ) : (
                      <button className="buyButton disabled" disabled title="data/products.json에 제휴 링크를 입력하세요">
                        링크 등록 필요
                      </button>
                    )}
                  </div>
                  <p className="finePrint">상품 옵션·가격·배송 정보는 쿠팡 상품 페이지에서 확인하세요.</p>
                </div>
              </article>
            )) : (
              <div className="empty">검색 결과가 없습니다. 다른 키워드로 검색해 보세요.</div>
            )}
          </section>

          <aside className="sidebar">
            <section className="sideBox">
              <h3>콘텐츠 제작 순서</h3>
              <div className="step"><b>1</b><div><strong>문제 상황 보여주기</strong><p>시청자가 공감할 일상 속 불편을 짧게 제시합니다.</p></div></div>
              <div className="step"><b>2</b><div><strong>상품 사용 장면</strong><p>직접 촬영했거나 사용 허가를 받은 영상으로 장점을 설명합니다.</p></div></div>
              <div className="step"><b>3</b><div><strong>상품 링크 연결</strong><p>쿠팡 파트너스에서 발급받은 정확한 제휴 링크를 연결합니다.</p></div></div>
            </section>
            <section className="sideBox">
              <h3>운영 전 체크리스트</h3>
              <ul className="checklist">
                <li>실제 제휴 링크 입력</li>
                <li>가격·상품 정보 확인</li>
                <li>제휴 고지 표시</li>
                <li>영상·이미지 사용 권한 확인</li>
                <li>쿠팡 파트너스에 운영 사이트 등록</li>
              </ul>
            </section>
          </aside>
        </div>

        <footer className="footer">
          <p>상품 정보는 구매 전 쿠팡의 최신 안내를 확인해 주세요. 가격과 판매 조건은 변경될 수 있습니다.</p>
          <p>© 픽숏 · 쇼핑 숏츠 데모</p>
        </footer>
      </div>
    </main>
  );
}
