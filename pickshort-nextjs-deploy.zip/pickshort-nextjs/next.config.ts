import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // 기본 설정으로 시작합니다. 필요 시 이미지 호스트 등을 추가하세요.
};

export default nextConfig;
